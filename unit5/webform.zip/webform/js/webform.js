
console.log("Test");
let response = document.getElementById("response");
let data = new URLSearchParams( window.location.search );

if ( window.location.search === "" ) {
    response.innerHTML = "<div class='card-header'><h3 class='card-title'>No form data entered!</h3></div>";
} else {
    let text = "<div class='card-header'><h3 class='card-title'>You entered...</h3></div><div class='card-body bg-white text-dark'><table class='table'>";
    text += `<thead class="table-primary"><tr><th>Field</th><td>Entry</td></tr></thead>`;
    data.forEach((value, key) => {
        text += `<tr><th>${key}</th><td>${value}</td></tr>`;
        console.log(value, key);
      });
    text += "</table></div>";
    response.innerHTML = text;
}


