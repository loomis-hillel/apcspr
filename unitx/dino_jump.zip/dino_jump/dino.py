import pygame
import sys
import random

# --- GLOBAL CONSTANTS ---
WIDTH, HEIGHT = 800, 600
FPS = 60
GRAVITY = 0.8
GROUND_Y = HEIGHT - 50
SPEED = 7

class Background:
    def __init__(self, image_path):
        raw_image = pygame.image.load(image_path).convert()
        self.image = pygame.transform.scale(raw_image, (WIDTH, HEIGHT))
        self.width = self.image.get_width()
        self.x1, self.x2 = 0, self.width

    def move(self, speed):
        self.x1 -= speed
        self.x2 -= speed
        if self.x1 <= -self.width: self.x1 = self.width
        if self.x2 <= -self.width: self.x2 = self.width

    def draw(self, screen):
        screen.blit(self.image, (self.x1, 0))
        screen.blit(self.image, (self.x2, 0))

class Dino(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()

        # Animation Dictionary
        # Keys match the folder names; Values will be lists of action frames
        self.animations = {"Dead": [], "Idle": [], "Jump": [], "Run": [], "Walk": []}
        self.load_assets()

        # State Tracking
        self.current_sequence = "Idle" # Start in the Run state
        self.frame_index = 0           # Which image in the list are we showing?
        self.animation_speed = 0.2     # Controls how fast the frames swap

        # Required Sprite Attributes
        self.image = self.animations[self.current_sequence][self.frame_index]
        self.rect = self.image.get_rect(bottomleft=(50, GROUND_Y))
        self.mask = pygame.mask.from_surface(self.image)

        # Physics State
        self.velocity_y = 0
        self.is_jumping = False

    def load_assets(self):
        """Automates loading and scaling for all 5 sequences."""
        # Define how many images are in each folder
        sequence_counts = {
            "Dead": 8,
            "Idle": 10,
            "Jump": 12,
            "Run": 8,
            "Walk": 10
        }

        for sequence, count in sequence_counts.items():
            for i in range(1, count + 1):
                path = f"res/dino/{sequence} ({i}).png"

                # Load, optimize, and scale
                img = pygame.image.load(path).convert_alpha()
                img = pygame.transform.scale(img, (100, 75))

                self.animations[sequence].append(img)

    def dead(self):
        self.current_sequence = "Dead"
        self.frame_index = 0

    def reset(self):
        self.current_sequence = "Idle"
        self.frame_index = 0
        self.rect.bottomleft = (50, GROUND_Y)
        self.velocity_y = 0
        self.is_jumping = False

    def animate(self):
        """Cycles through the frames of the current sequence."""
        self.frame_index += self.animation_speed

        # If we reach the end of the list, loop back to the start
        if self.current_sequence == "Dead" and \
            self.frame_index >= len(self.animations[self.current_sequence]):
            self.frame_index -= 1
        elif self.frame_index >= len(self.animations[self.current_sequence]):
            self.frame_index = 0

        # Update the active image
        self.image = self.animations[self.current_sequence][int(self.frame_index)]
        # Re-generate the mask for pixel-perfect collision every frame
        self.mask = pygame.mask.from_surface(self.image)

    def jump(self):
        if not self.is_jumping:
            self.velocity_y = -23
            self.is_jumping = True
            # Switch animation sequence
            self.current_sequence = "Jump"
            self.frame_index = 0

    def update(self, state):
        # Apply Gravity
        self.velocity_y += GRAVITY
        self.rect.y += self.velocity_y

        # Ground Collision Logic
        if self.rect.bottom >= GROUND_Y:
            self.rect.bottom = GROUND_Y
            self.velocity_y = 0
            if self.is_jumping:
                self.is_jumping = False
            self.current_sequence = state


class Cactus(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        raw_image = pygame.image.load("res/cactus.png").convert_alpha()
        self.image = pygame.transform.scale(raw_image, (89, 100))
        self.rect = self.image.get_rect(bottomleft=(WIDTH + 50, GROUND_Y))
        self.mask = pygame.mask.from_surface(self.image)

    def reset(self):
        self.rect.left = WIDTH + random.randint(50, 150)

    def update(self, speed):
        self.rect.x -= speed
        if self.rect.right < 0:
            self.rect.left = WIDTH + random.randint(50, 150)

def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Dino Jump: Individual Sprites")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("Arial", 40)

    bg = Background("res/background.png")

    # Individual Sprite Objects (No Groups)
    player = Dino()
    cactus = Cactus()

    first_game = True
    game_active = False
    running = True
    speed = SPEED

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_s and not game_active:
                    # Reset game state
                    game_active = True
                    player.reset()
                    cactus.reset()
                    speed = SPEED

                if event.key == pygame.K_SPACE and game_active:
                    player.jump()

        if game_active:
            # UPDATE (Handled individually)
            bg.move(speed=int(max(3, speed-3)))
            if speed < 10:
                player.update("Walk")
            else:
                player.update("Run")
            cactus.update(int(speed))
            speed += 0.001

            # COLLISION DETECTION
            if pygame.sprite.collide_mask(player, cactus):
                game_active = False
                first_game = False
                player.dead()

        # --- DRAWING PHASE ---
        # 1. Background
        bg.draw(screen)

        # 2. Objects (Manual Blitting because we have no Groups)
        player.animate()
        screen.blit(player.image, player.rect)
        screen.blit(cactus.image, cactus.rect)

        # 3. UI Overlay
        if not game_active:
            if not first_game:
                msg = "Game Over! Press 'S' to Restart"
            else:
                msg = "Press 'S' to Start"

            text_surf = font.render(msg, True, (255, 255, 255))
            text_rect = text_surf.get_rect(center=(WIDTH//2, HEIGHT//2))
            screen.blit(text_surf, text_rect)

        pygame.display.flip()
        clock.tick(FPS)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
