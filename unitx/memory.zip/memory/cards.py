import pygame
import random
import os


class Card(pygame.sprite.Sprite):
    def __init__(self, suit, value, face_image_path, back_image_path, pos):
        super().__init__()
        self.suit = suit
        self.value = value

        # Set the target size
        self.target_size = (96, 96)

        # Load and scale images automatically
        self.face_image = self._load_and_scale(face_image_path)
        self.back_image = self._load_and_scale(back_image_path)

        self.image = self.back_image
        self.rect = self.image.get_rect(topleft=pos)

        self.is_face_up = False
        self.matched = False

    def _load_and_scale(self, path):
        """Helper to load and force resize to 96x96."""
        img = pygame.image.load(path).convert_alpha()
        return pygame.transform.scale(img, self.target_size)

    def flip(self):
        if not self.matched:
            self.is_face_up = not self.is_face_up
            self.image = self.face_image if self.is_face_up else self.back_image

    def equals(self, other):
        if not isinstance(other, Card):
            return NotImplemented
        return self.suit == other.suit and self.value == other.value


class Deck:
    def __init__(self):
        self.suits = ['clubs', 'diamonds', 'hearts', 'spades']
        self.values = [f"{i:02d}" for i in range(2, 10)] + ['J', 'Q', 'K', 'A']
        self.back_path = os.path.join('res', 'card_back.png')

        self.deck = []
        for suit in self.suits:
            for value in self.values:
                face_path = os.path.join('res', f"card_{suit}_{value}.png")
                self.deck.append((suit, value, face_path))

    def draw(self, count_pairs=8):
        if count_pairs < 1 or count_pairs > 16:
            raise Exception('count_pairs must be between 1 and 16')
        pairs = random.sample(self.deck, count_pairs) * 2
        random.shuffle(pairs)
        return pairs


class PlayState:
    def __init__(self, size, time_limit_seconds):
        self.deck = Deck()
        self.size = size
        self.time_limit = time_limit_seconds  # Total time allowed in seconds
        self.start_ticks = None  # Will store the timestamp when game starts
        self.card_sprites = pygame.sprite.Group()
        self.reset()

    def start(self):
        """Begins the countdown timer."""
        self.start_ticks = pygame.time.get_ticks()

    def reset(self):
        self.card_pairs = self.deck.draw(self.size)
        self.card_sprites.empty()
        self.start_ticks = None  # Timer stays idle until start() is called

        cols = 6
        margin = 15
        card_size = 96

        for i, (suit, val, path) in enumerate(self.card_pairs):
            x = (i % cols) * (card_size + margin) + 80
            y = (i // cols) * (card_size + margin) + 80

            card = Card(suit, val, path, self.deck.back_path, (x, y))
            self.card_sprites.add(card)

    def check_timer(self):
        """Returns remaining seconds as an integer, or 0 if time is up or not started."""
        if self.start_ticks is None:
            return self.time_limit

        # Calculate elapsed time in seconds
        seconds_passed = (pygame.time.get_ticks() - self.start_ticks) // 1000
        remaining = self.time_limit - seconds_passed

        return max(0, remaining)