import pygame
from cards import Card, PlayState

def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    font = pygame.font.SysFont("Arial", 32)
    pygame.display.set_caption("Memory Game")
    clock = pygame.time.Clock()
    fps = 60

    game_state = PlayState(12, 60)
    game_state.start()

    # Selection State Variables
    first_card = None
    second_card = None

    running = True
    while running:
        time_left = game_state.check_timer()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    game_state.reset()
                    game_state.start()
                    first_card = second_card = None

            if event.type == pygame.MOUSEBUTTONDOWN and time_left > 0:
                for card in game_state.card_sprites:
                    # Only allow clicking if card is face down and not already matched
                    if card.rect.collidepoint(event.pos) and not card.is_face_up and not card.matched:

                        # 1. If two cards were already showing from a previous mismatch
                        # Flip them back before starting the new cycle
                        pass

                        # 2. Select the first card

                        # 3. Select the second card

                        # 4. Immediate Match Check


        # Rendering
        screen.fill((34, 139, 34))

        timer_text = font.render(f"Time Remaining: {time_left}s", True, (255, 255, 255))
        screen.blit(timer_text, (20, 20))

        if time_left <= 0:
            over_text = font.render("GAME OVER!", True, (255, 0, 0))
            screen.blit(over_text, (320, 300))
            clock.tick(fps)
        # Check for Win Condition (All cards matched)
        elif all(card.matched for card in game_state.card_sprites):
            win_text = font.render("YOU WIN!", True, (255, 255, 0))
            screen.blit(win_text, (340, 300))
            running = False
        else:
            game_state.card_sprites.draw(screen)

        pygame.display.flip()
        clock.tick(fps)
        # If game over then pause for a second
        if running == False:
            clock.tick(1000)

    pygame.time.delay(2500)
    pygame.quit()

if __name__ == "__main__":
    main()
