#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>

/** The maximum capacity of the array. */


void reverse ( int numbers [], int size );
int max ( int [], int );
void printArray ( int [], int );
int fillArray ( int [] );

/**
 * Reads an array of integers from a file and displays the array in the
 * terminal. Finds and outputs the maximum number found in the array. Then
 * reverses order of the elements in the array and prints the array (reversed).
 * Author: <Your name here>
*/
int main ( void ) {
    // Declare the array below
    
    int size = fillArray ( numbers );
    printArray ( numbers, size );
    printf ( "Max: %i\n", max ( numbers, size) );
    reverse ( numbers, size );
    printArray ( numbers, size );
    return 0;
}

/**
 * Reverses the array of numbers.
*/
void reverse ( int numbers [], int size ){
   // Complete this function for task #3
}

/**
 * Produces the maximum value in an array of ints
*/
int max ( int numbers [], int size ){
    int max = 0;
    // Complete this function for task #2
    return max;
}

/**
 * Outputs the array to the terminal window.
*/
void printArray ( int numbers [], int size ) {
    // Complete this function for task #1
}

/**
 * Reads the data from user input and stores it in the given array.
 * Produces the number of elements read from the file as the
 * return value.
*/
int fillArray ( int numbers[] ) {

    int number;

    // Open the data file
    string filename = get_string ( "Enter the name of the file: " );
    FILE *in_file  = fopen(filename, "r");
    if (in_file == NULL ) {
        printf("Could not open file.\n");
        exit(-1);
    }

    // Read the file data and add it to the array. This is new for use
    // Each number in the file is stored in 'number' and is then added to the array.
    int i;
    for ( i=0; i<CAPACITY && fscanf(in_file, "%d", &number ) > 0; i++ ) {
        // Add the number to the array.
        numbers[i] = number;
    }
    return i;
}
