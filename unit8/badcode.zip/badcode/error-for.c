#include <stdio.h>
#include <cs50.h>

/**
 * error-for.c
 *
 * This program contains errors which prevents it from being
 * a correct solution. Correct the errors so that it correctly
 * performs the task below.
 *
 * Produces the numbers 1 through 10 as output to the terminal
 *
 * @author Ken Loomis
 */
int main(){ for
( int
i=0; i<10;
printf("%i\n"
, ++i)); }
