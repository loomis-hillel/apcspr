#include <stdio.h>
#include <cs50.h>


/**
 * error-semicolon.c
 *
 * This program contains errors which prevents it from being
 * a correct solution. Correct the errors so that it correctly
 * performs the task below.
 *
 * Produces a "Hello, world" message to the terminal.
 *
 * @author Ken Loomis
 */
int main ( )
{
	printf ( "Hello, world\n" )
	return 0;
}
