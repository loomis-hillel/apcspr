from random import randrange
from collections import defaultdict

MIN_WORD_LENGTH = 5
MAX_WORD_LENGTH = 5
DICTIONARY = "dictionaries/small.dat"

def main ( ):
    """ Plays a game like wordle where the user has as
        many tries to guess the word as the length of the
        target word.
    """
    print ( "Welcome to Wordle!")
    # Write the missing main code here

# Write getHint here

def loadWordList( ):
    """ Loads the list of words from the dictionary """
    with open( DICTIONARY, 'r' ) as file:
        wordlist = file.read().split()
    wordlist = [word.strip() for word in wordlist if word.isalpha()]
    return wordlist

def getWord ( wordlist, minsize, maxsize ):
    """ Picks one word at random within the given size """
    word = getRandomWord(wordlist)
    while len(word) < minsize or len(word) > maxsize or \
        not word in wordlist:
        word = getRandomWord(wordlist)
    return word

def getRandomWord( wordlist ):
    """ Picks one word at random from the wordlist """
    index = randrange (0, len(wordlist))
    return wordlist[index]

def getGuess ( size, wordlist ):
    """ Gets a guess of the correct size from the user. Words
        that are not in the dictionary are rejected. """
    guess = input ( "Guess:\t" ).lower()
    while ( len(guess) != size or guess not in wordlist ):
        guess = input ( "INVALID\nGuess:\t" )
    return guess

main()