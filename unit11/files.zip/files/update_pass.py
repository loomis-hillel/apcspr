from datetime import datetime
import csv
from hashlib import sha256

"""
    This program demonstrates the ability to open a file
    and update a record in the file. In reality, it takes
    two steps. Opening the file and loading the data.
    Making the change in the data and saving the updates.
"""

print ( "Loads the CSV file: " )
with open("users2.csv", "r") as csv_file:
    contents = list (csv.reader( csv_file ))
print ( contents )

print ( )

print ( "Demonstrates the ability to update the data: " )
username = input ( "Enter your username: " )
oldpwd = input ( "Enter your old password: " )
oldpwd = sha256( oldpwd.encode() ).hexdigest()
newpwd = input ( "Enter your new password: " )
date = datetime.now()
updated = False
for row in contents:
    if row[0] == username and row[1] == oldpwd:
        ## Hash passwords
        row[1] = sha256( newpwd.encode() ).hexdigest()
        row[2] = str(date)
        updated = True
    elif row[0] == username:
        print ( "Invalid Password!" )
        exit( 0 )
if not updated:
    contents.append( [ username, 
                       sha256( newpwd.encode() ).hexdigest(), 
                       str(date) ] )

with open("users2.csv", "w") as csv_file:
    writer = csv.writer ( csv_file )
    for row in contents:
        writer.writerow ( row )
print ( "Open users2.csv to see the data update in the file" )
